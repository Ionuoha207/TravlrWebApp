// app_server/controllers/travlr.js
module.exports.travel = function(req, res) {
    res.render('travel', { title: 'Travlr Getaways - Travel' });
};
